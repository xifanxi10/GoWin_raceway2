param([Parameter(Mandatory=$true)][string]$JdkHome,[Parameter(Mandatory=$true)][string]$JsonJar)
$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot
$out=Join-Path $project 'build-tests'
New-Item -ItemType Directory -Force $out | Out-Null
& (Join-Path $JdkHome 'bin/javac.exe') -encoding UTF-8 --release 8 -cp $JsonJar -d $out (Join-Path $project 'app/src/main/java/cn/pianolink/Wire.java') (Join-Path $project 'app/src/main/java/cn/pianolink/Models.java') (Join-Path $project 'app/src/main/java/cn/pianolink/MidiScore.java') (Join-Path $project 'app/src/main/java/cn/pianolink/OnlineCatalog.java') (Join-Path $PSScriptRoot 'CoreTest.java') (Join-Path $PSScriptRoot 'OnlineMidiTest.java')
if($LASTEXITCODE -ne 0){throw 'Test compilation failed'}
& (Join-Path $JdkHome 'bin/java.exe') -cp "$out;$JsonJar" cn.pianolink.CoreTest
if($LASTEXITCODE -ne 0){throw 'Core tests failed'}
& (Join-Path $JdkHome 'bin/java.exe') -cp "$out;$JsonJar" cn.pianolink.OnlineMidiTest
if($LASTEXITCODE -ne 0){throw 'MIDI tests failed'}
