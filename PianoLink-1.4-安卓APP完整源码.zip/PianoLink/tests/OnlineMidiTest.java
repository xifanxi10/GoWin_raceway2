package cn.pianolink;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.json.*;

public class OnlineMidiTest {
    static int count;
    static void check(boolean ok,String why){count++;if(!ok)throw new AssertionError(why);}
    interface Work{void run() throws Exception;}
    static void rejects(Work w,String why)throws Exception{boolean hit=false;try{w.run();}catch(Exception e){hit=true;}check(hit,why);}
    static byte[] smf(int division,byte[]... tracks)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream d=new DataOutputStream(b);d.writeBytes("MThd");d.writeInt(6);d.writeShort(tracks.length==1?0:1);d.writeShort(tracks.length);d.writeShort(division);for(byte[] track:tracks){d.writeBytes("MTrk");d.writeInt(track.length);d.write(track);}return b.toByteArray();}
    static byte[] bytes(int... nums){byte[] b=new byte[nums.length];for(int i=0;i<b.length;i++)b[i]=(byte)nums[i];return b;}
    public static void main(String[] args)throws Exception {
        byte[] simple=smf(480,bytes(0,0x90,60,80,0x83,0x60,60,0,0,0xff,0x2f,0));
        MidiScore.Song a=MidiScore.parse(simple);check(a.notes.size()==1&&a.notes.get(0).end==500,"running status / default tempo");
        MidiScore.Converted c=MidiScore.convert(a,-1,0,false,"test",new JSONObject().put("url","https://example.org/"));check(c.score.getJSONArray("notes").length()==1,"convert note");check(Models.score(c.score.toString()).getJSONObject("source").has("adaptation"),"source survives normalisation");
        byte[] conductor=bytes(0,255,81,3,7,161,32,0x83,0x60,255,81,3,15,66,64,0,255,47,0);
        byte[] line=bytes(0,0x90,60,80,0x87,0x40,0x80,60,0,0,255,47,0);
        MidiScore.Song tempo=MidiScore.parse(smf(480,conductor,line));check(tempo.notes.get(0).end==1500&&tempo.tempoChanges,"tempo map across tracks");
        rejects(()->MidiScore.parse(smf(0xE728,line)),"unsupported SMPTE");
        rejects(()->MidiScore.parse(Arrays.copyOf(simple,simple.length-2)),"truncated track");
        rejects(()->MidiScore.parse(smf(480,bytes(0,60,80,0,255,47,0))),"running status without status");
        rejects(()->MidiScore.parse(smf(480,bytes(0x81,0x81,0x81,0x81,0,255,47,0))),"oversized varint");
        rejects(()->MidiScore.parse(smf(480,bytes(0,255,81,3,0,0,0))),"zero tempo");
        rejects(()->MidiScore.parse(smf(480,bytes(0,0x99,40,100,20,0x89,40,0))),"drums excluded");
        MidiScore.Song low=MidiScore.parse(smf(480,bytes(0,0x90,36,80,0x83,0x60,0x80,36,0,0,255,47,0)));
        rejects(()->MidiScore.convert(low,-1,0,false,"low",null),"out of range requires fold opt-in");
        check(MidiScore.convert(low,-1,0,true,"low",null).score.getJSONArray("notes").getJSONObject(0).getInt("note")==48,"octave fold");
        JSONArray notes=new JSONArray();for(int i=0;i<600;i++)notes.put(new JSONObject().put("at",(i/3)*100).put("duration",80).put("note",60+i%3).put("velocity",80));
        JSONObject longScore=new JSONObject().put("version",1).put("title","chords").put("bpm",120).put("notes",notes);
        MidiScore.Song longSong=MidiScore.fromScore(longScore);ArrayList<ArrayList<MidiScore.Note>> chunks=longSong.segments(-1);check(chunks.size()==3,"long score split");int sum=0;for(int i=0;i<chunks.size();i++){sum+=chunks.get(i).size();check(chunks.get(i).size()<=256&&chunks.get(i).size()%3==0,"do not split chord boundary");check(MidiScore.convert(longSong,-1,i,false,"long",null).score.getJSONArray("notes").getJSONObject(0).getInt("at")==0,"segment normalised");}check(sum==600,"no dropped notes during segmentation");
        check(OnlineCatalog.keyword("鸡你太美").equals("只因你太美"),"song alias");check(OnlineCatalog.keyword("致爱丽丝").equals("Elise"),"Chinese classical alias");
        if(args.length>0){Path root=Paths.get(args[0]);ArrayList<OnlineCatalog.Entry> found=OnlineCatalog.parseResults(new String(Files.readAllBytes(root.resolve("search.html")),"UTF-8"));check(found.size()==2,"real Elise search results");OnlineCatalog.Entry piano=null;for(OnlineCatalog.Entry e:found)if(e.instrument.equals("Piano"))piano=e;check(piano!=null&&piano.license.equals("Public Domain"),"real MIDI and license metadata");
            check(OnlineCatalog.parseResults(new String(Files.readAllBytes(root.resolve("bach-search.html")),"UTF-8")).size()>=5,"real paginated search");
            check(OnlineCatalog.parseResults(new String(Files.readAllBytes(root.resolve("twinkle-search.html")),"UTF-8")).size()>0,"real Twinkle search");
            MidiScore.Song real=MidiScore.parse(Files.readAllBytes(root.resolve("elise.mid")));check(real.notes.size()>500&&real.parts.size()>=2,"downloaded real multitrack MIDI");
            int total=0;for(int i=0;i<real.segments(-1).size();i++){MidiScore.Converted piece=MidiScore.convert(real,-1,i,true,"致爱丽丝",piano.source());JSONObject validated=Models.score(piece.score.toString());check(validated.getJSONArray("notes").length()<=256,"real converted segment capacity");total+=validated.getJSONArray("notes").length();if(i==0)Files.write(root.resolve("converted-elise.json"),piece.score.toString().getBytes("UTF-8"));}
            check(total==real.notes.size(),"real MIDI preserved across segments");System.out.println("Real MIDI: "+real.notes.size()+" notes; "+real.parts.size()+" parts; "+real.segments(-1).size()+" segments");
        }
        System.out.println("PASS "+count+" online/MIDI checks");
    }
}
