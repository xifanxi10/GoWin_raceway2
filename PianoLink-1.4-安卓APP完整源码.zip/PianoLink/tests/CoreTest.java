package cn.pianolink;
import java.util.*;
import java.nio.charset.StandardCharsets;
import org.json.*;

public class CoreTest {
    static int checks;
    static void check(boolean b,String message){checks++;if(!b)throw new AssertionError(message);}
    interface Action {void run() throws Exception;}
    static void rejects(Action a,String name) throws Exception {boolean rejected=false;try{a.run();}catch(Exception e){rejected=true;}check(rejected,name);}
    public static void main(String[] args) throws Exception {
        check(Wire.crc("123456789".getBytes(StandardCharsets.US_ASCII),0,9)==0x29b1,"CCITT reference vector");
        Random r=new Random(20261031);int[] received={0};
        Wire.Parser parser=new Wire.Parser((t,s,p)->{check(t==Wire.HELLO&&s==65535&&new String(p,StandardCharsets.UTF_8).equals("测试"),"frame contents");received[0]++;});
        byte[] f=Wire.pack(Wire.HELLO,65535,"测试".getBytes(StandardCharsets.UTF_8));
        for(byte b:f)parser.feed(new byte[]{b},1);check(received[0]==1,"byte fragmentation");
        byte[] joined=new byte[f.length*2];System.arraycopy(f,0,joined,0,f.length);System.arraycopy(f,0,joined,f.length,f.length);parser.feed(joined,joined.length);check(received[0]==3,"coalesced frames");
        byte[] damaged=f.clone();damaged[8]^=1;parser.feed(damaged,damaged.length);parser.feed(f,f.length);check(received[0]==4&&parser.badFrames>0,"CRC damage recovery");
        byte[] badLength={0x50,0x4c,1,1,0,0,(byte)255,(byte)255};parser.feed(badLength,badLength.length);parser.feed(f,f.length);check(received[0]==5,"invalid length recovery");
        rejects(()->Wire.pack(1,1,new byte[769]),"frame limit");
        for(int iteration=0;iteration<100;iteration++) {byte[] payload=new byte[r.nextInt(769)];r.nextBytes(payload);int[] seen={0};Wire.Parser p=new Wire.Parser((t,s,v)->{check(Arrays.equals(payload,v),"random fragmented payload");seen[0]++;});byte[] frame=Wire.pack(32,iteration,payload);for(int off=0;off<frame.length;){int n=Math.min(1+r.nextInt(29),frame.length-off);p.feed(Arrays.copyOfRange(frame,off,off+n),n);off+=n;}check(seen[0]==1,"random exactly once");}
        JSONObject example=Models.score(Models.example().toString());check(example.getJSONArray("notes").length()==30,"Ode to Joy example parse");
        JSONObject invalid=new JSONObject(example.toString());invalid.getJSONArray("notes").getJSONObject(0).put("note",96);rejects(()->Models.score(invalid.toString()),"unsupported note");
        JSONObject fraction=new JSONObject(example.toString()).put("bpm",120.5);rejects(()->Models.score(fraction.toString()),"fractional integer");
        JSONObject duration=new JSONObject(example.toString());duration.getJSONArray("notes").getJSONObject(0).put("duration",-1);rejects(()->Models.score(duration.toString()),"negative duration");
        JSONObject overflow=new JSONObject(example.toString());overflow.getJSONArray("notes").getJSONObject(0).put("at",Models.MAX_TIME);rejects(()->Models.score(overflow.toString()),"duration overflow");
        rejects(()->Models.read(new java.io.ByteArrayInputStream(new byte[Models.LIMIT+1])),"download size limit");
        JSONArray events=new JSONArray();events.put(event(0,100,12,60,true,90));events.put(event(1,110,14,64,true,70));events.put(event(2,400,12,60,false,0));events.put(event(3,600,14,64,false,0));
        JSONObject rec=new JSONObject().put("version",1).put("kind","performance").put("session","test").put("events",events);
        Models.recording(rec);JSONObject replay=Models.replayScore(rec);check(replay.getJSONArray("notes").length()==2,"polyphonic recording replay");check(replay.getJSONArray("notes").getJSONObject(0).getInt("duration")==300,"hold duration");check(replay.getJSONArray("notes").getJSONObject(1).getInt("velocity")==70,"velocity retention");
        JSONObject duplicate=new JSONObject(rec.toString());duplicate.getJSONArray("events").getJSONObject(3).put("id",2);rejects(()->Models.recording(duplicate),"duplicate event id");
        JSONObject disorder=new JSONObject(rec.toString());disorder.getJSONArray("events").getJSONObject(3).put("t",0);rejects(()->Models.recording(disorder),"timestamp order");
        JSONObject wrongSession=new JSONObject(rec.toString());wrongSession.getJSONArray("events").getJSONObject(0).put("session","old");rejects(()->Models.recording(wrongSession),"wrong session");
        JSONArray orphan=new JSONArray().put(event(0,100,12,60,true,80));JSONObject cut=new JSONObject(rec.toString()).put("events",orphan);check(Models.replayScore(cut).getJSONArray("notes").getJSONObject(0).getInt("duration")==200,"interrupted release");
        System.out.println("PASS "+checks+" checks (framing, CRC, fragmentation, validation, event replay)");
    }
    static JSONObject event(int id,int t,int key,int note,boolean on,int velocity) throws Exception{return new JSONObject().put("session","test").put("id",id).put("t",t).put("key",key).put("note",note).put("velocity",velocity).put("on",on).put("measured",false);}
}
