param(
    [Parameter(Mandatory=$true)][string]$JdkHome,
    [Parameter(Mandatory=$true)][string]$AndroidJar,
    [Parameter(Mandatory=$true)][string]$BuildTools,
    [string]$BuildDirectory = (Join-Path $PSScriptRoot 'build-manual'),
    [string]$ApkPath = (Join-Path $PSScriptRoot 'PianoLink-debug.apk')
)
$ErrorActionPreference='Stop'
function Check-Exit { if ($LASTEXITCODE -ne 0) { throw "Build command failed: $LASTEXITCODE" } }
$env:JAVA_HOME=$JdkHome
New-Item -ItemType Directory -Force $BuildDirectory,(Join-Path $BuildDirectory 'classes'),(Join-Path $BuildDirectory 'dex') | Out-Null
$res=Join-Path $PSScriptRoot 'app/src/main/res'
& (Join-Path $BuildTools 'aapt2.exe') compile --dir $res -o (Join-Path $BuildDirectory 'resources.zip'); Check-Exit
$manifest=(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'app/src/main/AndroidManifest.xml') -Raw) -replace '<manifest ', '<manifest package="cn.pianolink" '
[IO.File]::WriteAllText((Join-Path $BuildDirectory 'AndroidManifest.xml'),$manifest,[Text.UTF8Encoding]::new($false))
& (Join-Path $BuildTools 'aapt2.exe') link -o (Join-Path $BuildDirectory 'base.apk') -I $AndroidJar --manifest (Join-Path $BuildDirectory 'AndroidManifest.xml') --min-sdk-version 26 --target-sdk-version 35 --version-code 5 --version-name 1.4 --auto-add-overlay (Join-Path $BuildDirectory 'resources.zip'); Check-Exit
$sources=Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'app/src/main/java') -Recurse -Filter '*.java' | ForEach-Object {$_.FullName}
& (Join-Path $JdkHome 'bin/javac.exe') -encoding UTF-8 --release 8 -classpath $AndroidJar -d (Join-Path $BuildDirectory 'classes') @sources; Check-Exit
& (Join-Path $JdkHome 'bin/jar.exe') "-J-Djava.io.tmpdir=$BuildDirectory" cf (Join-Path $BuildDirectory 'classes.jar') -C (Join-Path $BuildDirectory 'classes') .; Check-Exit
& (Join-Path $BuildTools 'd8.bat') --lib $AndroidJar --min-api 26 --output (Join-Path $BuildDirectory 'dex') (Join-Path $BuildDirectory 'classes.jar'); Check-Exit
Copy-Item -LiteralPath (Join-Path $BuildDirectory 'base.apk') -Destination (Join-Path $BuildDirectory 'unsigned.apk') -Force
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open((Join-Path $BuildDirectory 'unsigned.apk'),[IO.Compression.ZipArchiveMode]::Update)
try { [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Join-Path $BuildDirectory 'dex/classes.dex'),'classes.dex') | Out-Null } finally {$zip.Dispose()}
& (Join-Path $BuildTools 'zipalign.exe') -f 4 (Join-Path $BuildDirectory 'unsigned.apk') (Join-Path $BuildDirectory 'aligned.apk'); Check-Exit
$key=Join-Path $BuildDirectory 'debug.jks'
if(!(Test-Path -LiteralPath $key)) { & (Join-Path $JdkHome 'bin/keytool.exe') -genkeypair -keystore $key -storepass android -keypass android -alias androiddebugkey -dname 'CN=PianoLink Development' -keyalg RSA -keysize 2048 -validity 3650; Check-Exit }
& (Join-Path $BuildTools 'apksigner.bat') sign --ks $key --ks-pass pass:android --key-pass pass:android --out $ApkPath (Join-Path $BuildDirectory 'aligned.apk'); Check-Exit
& (Join-Path $BuildTools 'apksigner.bat') verify --verbose $ApkPath; Check-Exit
Write-Output "APK: $ApkPath"


