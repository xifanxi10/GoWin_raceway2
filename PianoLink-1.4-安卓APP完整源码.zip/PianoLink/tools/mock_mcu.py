"""PianoLink v1 reference receiver, not STM32 firmware.

python tools/mock_mcu.py --self-test
python tools/mock_mcu.py --port COM6 --baud 115200

Serial mode needs pyserial and a USB-TTL adapter wired to the HC-05 UART,
in place of the STM32. Android connects to HC-05 via Bluetooth. Terminal keys
1/2/3/4 generate C4/D4/E4/G4 down+up pairs while recording. Ctrl+C exits.
No audio, screen or flash implementation is implied by mock ACKs.
"""
import argparse
import base64
import collections
import hashlib
import json
import struct
import threading
import time


def crc(data):
    value = 0xFFFF
    for b in data:
        value ^= b << 8
        for _ in range(8):
            value = ((value << 1) ^ (0x1021 if value & 0x8000 else 0)) & 0xFFFF
    return value


def pack(kind, seq, obj):
    payload = json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    if len(payload) > 768:
        raise ValueError('payload too large')
    body = struct.pack('<BBHH', 1, kind, seq, len(payload)) + payload
    return b'PL' + body + struct.pack('<H', crc(body))


class Parser:
    def __init__(self):
        self.buffer = bytearray()

    def feed(self, data):
        self.buffer.extend(data)
        frames = []
        while len(self.buffer) >= 8:
            if self.buffer[:2] != b'PL':
                del self.buffer[0]
                continue
            version, kind, seq, size = struct.unpack_from('<BBHH', self.buffer, 2)
            if version != 1 or size > 768:
                del self.buffer[0]
                continue
            end = size + 10
            if len(self.buffer) < end:
                break
            if crc(self.buffer[2:end-2]) != struct.unpack_from('<H', self.buffer, end-2)[0]:
                del self.buffer[0]
                continue
            payload = bytes(self.buffer[8:end-2])
            del self.buffer[:end]
            frames.append((kind, seq, payload))
        return frames


class Mock:
    def __init__(self):
        self.cache = collections.OrderedDict()
        self.stage = None
        self.committed = {}
        self.session = None
        self.event_id = 0
        self.start = 0
        self.guide = None

    def handle(self, kind, seq, payload):
        identity = kind, seq, payload
        if identity in self.cache:
            return self.cache[identity]
        ack = {'for': kind, 'status': 0}
        try:
            obj = json.loads(payload)
            if kind == 1:
                if obj.get('protocol') != 1:
                    raise ValueError('unsupported protocol')
                self.session = None
                self.stage = None
                ack.update(protocol=1, max_blob=262144, mock=True)
            elif kind == 16:
                if obj['kind'] not in ('score', 'mapping') or not 1 <= obj['size'] <= 262144:
                    raise ValueError('invalid object type or size')
                self.stage = dict(obj, content=bytearray())
            elif kind == 17:
                stage = self.stage
                if stage is None or stage['id'] != obj['id']:
                    raise ValueError('unknown transaction')
                data = base64.b64decode(obj['data'], validate=True)
                offset = obj['offset']
                if not 0 <= offset <= len(stage['content']) or not 1 <= len(data) <= 384:
                    raise ValueError('invalid offset or chunk size')
                if offset < len(stage['content']):
                    if stage['content'][offset:offset+len(data)] != data:
                        raise ValueError('conflicting duplicate chunk')
                else:
                    if offset+len(data) > stage['size']:
                        raise ValueError('size overflow')
                    stage['content'].extend(data)
            elif kind == 18:
                stage = self.stage
                if stage is None or stage['id'] != obj['id']:
                    raise ValueError('unknown transaction')
                data = bytes(stage['content'])
                if len(data) != stage['size'] or hashlib.sha256(data).hexdigest() != stage['sha256']:
                    raise ValueError('size or SHA-256 mismatch')
                value = json.loads(data)
                validate(stage['kind'], value)
                self.committed[stage['kind']] = value
                self.stage = None
            elif kind == 32:
                if obj['action'] == 'stop':
                    self.guide = None
                elif obj['action'] == 'start' and obj['mode'] in ('guide', 'replay'):
                    if 'score' not in self.committed:
                        raise ValueError('no committed score')
                    self.guide = obj['mode']  # MOCK ONLY, no audio or display.
                else:
                    raise ValueError('invalid guide action')
            elif kind == 48:
                if self.session is not None:
                    raise ValueError('already recording')
                self.session = obj['session']
                self.event_id = 0
                self.start = time.monotonic()
            elif kind == 49:
                if obj['session'] != self.session:
                    raise ValueError('unknown recording session')
                ack['event_count'] = self.event_id
                self.session = None
            else:
                raise ValueError('unsupported command')
        except (KeyError, TypeError, ValueError) as exc:
            ack.update(status=1, message=str(exc))
        result = pack(128, seq, ack)
        self.cache[identity] = result
        while len(self.cache) > 32:
            self.cache.popitem(last=False)
        return result

    def event(self, key, on):
        if self.session is None:
            return b''
        mapping = self.committed.get('mapping', {}).get('notes', list(range(48, 96)))
        event = dict(session=self.session, id=self.event_id,
                     t=int((time.monotonic()-self.start)*1000), key=key,
                     note=mapping[key], velocity=80 if on else 0, on=on, measured=False)
        result = pack(50, self.event_id & 65535, event)
        self.event_id += 1
        return result


def integer(value, minimum, maximum):
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError('integer out of range')


def validate(kind, value):
    integer(value['version'], 1, 1)
    if kind == 'mapping':
        integer(value['base'], 48, 48)
        if len(value['notes']) != 48:
            raise ValueError('need 48 mapping entries')
        for note in value['notes']:
            integer(note, 48, 95)
    else:
        if not isinstance(value['title'], str) or not 1 <= len(value['title']) <= 64:
            raise ValueError('invalid title')
        integer(value['bpm'], 30, 240)
        if not 1 <= len(value['notes']) <= 4096:
            raise ValueError('invalid note count')
        for note in value['notes']:
            integer(note['at'], 0, 1800000)
            integer(note['duration'], 20, 1800000-note['at'])
            integer(note['note'], 48, 95)
            integer(note['velocity'], 1, 127)


def self_test():
    assert crc(b'123456789') == 0x29B1
    p = Parser()
    frame = pack(1, 65535, {'protocol': 1})
    decoded = []
    for byte in frame:
        decoded.extend(p.feed(bytes([byte])))
    assert len(decoded) == 1 and decoded[0][:2] == (1, 65535)
    mock = Mock()
    counter = 0

    def request(kind, obj):
        nonlocal counter
        counter += 1
        payload = json.dumps(obj, separators=(',', ':')).encode()
        answer = mock.handle(kind, counter, payload)
        assert mock.handle(kind, counter, payload) == answer  # Duplicate request is idempotent.
        return json.loads(Parser().feed(answer)[0][2])

    assert request(1, {'protocol': 1})['status'] == 0
    score = {'version': 1, 'title': 'test', 'bpm': 120,
             'notes': [{'at': 0, 'duration': 500, 'note': 60, 'velocity': 80}]}
    data = json.dumps(score).encode()
    assert request(16, dict(id='x', kind='score', size=len(data), sha256=hashlib.sha256(data).hexdigest()))['status'] == 0
    assert request(17, dict(id='x', offset=0, data=base64.b64encode(data).decode()))['status'] == 0
    assert request(18, dict(id='x'))['status'] == 0
    assert mock.committed['score'] == score
    assert request(32, dict(action='start', mode='replay'))['status'] == 0
    assert request(48, dict(session='abc'))['status'] == 0
    assert json.loads(Parser().feed(mock.event(12, True))[0][2])['id'] == 0
    assert json.loads(Parser().feed(mock.event(12, False))[0][2])['id'] == 1
    assert request(49, dict(session='abc'))['event_count'] == 2
    assert request(16, dict(id='bad', kind='score', size=len(data), sha256='0'*64))['status'] == 0
    assert request(17, dict(id='bad', offset=0, data=base64.b64encode(data).decode()))['status'] == 0
    assert request(18, dict(id='bad'))['status'] != 0
    assert mock.committed['score'] == score  # Rejected commit preserves previous score.
    print('PASS mock MCU: framing, idempotent ACKs, SHA commit, replay, event_count, rejected commit')


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('--self-test', action='store_true')
    args.add_argument('--port')
    args.add_argument('--baud', type=int, default=115200)
    opts = args.parse_args()
    if opts.self_test:
        self_test()
        return
    if not opts.port:
        args.error('specify --port or --self-test')
    import serial  # pip install pyserial; only needed for serial mode.
    with serial.Serial(opts.port, opts.baud, timeout=0.05) as port:
        engine, parser, lock = Mock(), Parser(), threading.Lock()

        def console():
            import msvcrt
            keys = {'1': 12, '2': 14, '3': 16, '4': 19}
            while True:
                ch = msvcrt.getwch()
                if ch in keys:
                    with lock:
                        session = engine.session
                        port.write(engine.event(keys[ch], True))
                    time.sleep(0.25)
                    with lock:
                        if session == engine.session:
                            port.write(engine.event(keys[ch], False))

        threading.Thread(target=console, daemon=True).start()
        print('MOCK ONLY: connect Android to HC-05; terminal keys 1/2/3/4 create events; Ctrl+C exits.')
        try:
            while True:
                for kind, seq, payload in parser.feed(port.read(1024)):
                    with lock:
                        port.write(engine.handle(kind, seq, payload))
                    print('RX', hex(kind), seq, payload[:100])
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
