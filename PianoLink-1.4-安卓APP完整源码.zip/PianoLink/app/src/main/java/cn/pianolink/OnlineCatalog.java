package cn.pianolink;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import org.json.*;

/** Public Mutopia search pages; website-only results never masquerade as MIDI downloads. */
public final class OnlineCatalog {
    public static final String BASE="https://www.mutopiaproject.org/";
    public static final class Entry {
        public String title,composer,instrument,license,page,midi;
        public JSONObject source() throws Exception {return new JSONObject().put("provider","Mutopia Project").put("title",title).put("composer",composer).put("license",license).put("url",page).put("midi",midi);}
    }
    public static String keyword(String query) {
        String q=query.trim();String[][] aliases={{"鸡你太美","只因你太美"},{"致爱丽丝","Elise"},{"致爱丽斯","Elise"},{"小星星","Twinkle"},{"欢乐颂","Ode to Joy"},{"卡农","Pachelbel Canon"},{"贝多芬","Beethoven"},{"莫扎特","Mozart"},{"巴赫","Bach"},{"肖邦","Chopin"},{"舒伯特","Schubert"},{"柴可夫斯基","Tchaikovsky"},{"土耳其进行曲","Alla Turca"},{"月光奏鸣曲","Moonlight"},{"梦幻曲","Traumerei"}};
        for(String[] a:aliases)q=q.replace(a[0],a[1]);return q;
    }
    public static ArrayList<Entry> search(String query,int offset) throws Exception {
        String q=keyword(query);if(q.length()<1||q.length()>80)throw new IOException("请输入1~80字的曲名或作曲家");
        URL url=new URL(BASE+"cgibin/make-table.cgi?searchingfor="+URLEncoder.encode(q,"UTF-8")+"&startat="+offset);
        return parseResults(new String(fetch(url,1024*1024,true),StandardCharsets.UTF_8));
    }
    public static byte[] fetch(URL start,int maximum,boolean mutopiaOnly) throws Exception {
        URL url=start;
        for(int hops=0;hops<=4;hops++){
            if(!url.getProtocol().equals("https")||url.getUserInfo()!=null)throw new IOException("下载地址必须是HTTPS");
            if(mutopiaOnly&&!url.getHost().equals("www.mutopiaproject.org")&&!url.getHost().equals("mutopiaproject.org"))throw new IOException("曲库跳转到了其他网站，请使用原网页下载");
            HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(12000);c.setReadTimeout(20000);c.setRequestProperty("User-Agent","PianoLink/1.1 (Android MIDI practice client)");
            try {int code=c.getResponseCode();if(code==301||code==302||code==303||code==307||code==308){String next=c.getHeaderField("Location");if(next==null)throw new IOException("无效的下载跳转");url=new URL(url,next);continue;}
                if(code==403||code==401)throw new IOException("该网站要求登录或不允许直接下载，请在浏览器中打开原网页");
                if(code!=200)throw new IOException("曲库暂时不可用，HTTP "+code);
                return read(c.getInputStream(),maximum);
            }finally{c.disconnect();}
        }throw new IOException("下载跳转次数过多");
    }
    public static byte[] read(InputStream input,int maximum) throws Exception {
        if(input==null)throw new IOException("无法读取文件");try(InputStream in=input;ByteArrayOutputStream out=new ByteArrayOutputStream()) {byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>maximum)throw new IOException("文件大小超过允许范围");out.write(b,0,n);}return out.toByteArray();}
    }
    public static ArrayList<Entry> parseResults(String html) throws Exception {
        ArrayList<Entry> results=new ArrayList<>();Set<String> seen=new HashSet<>();
        Pattern tables=Pattern.compile("<table\\b[^>]*class=[\"'][^\"']*\\bresult-table\\b[^\"']*[\"'][^>]*>(.*?)</table>",Pattern.CASE_INSENSITIVE|Pattern.DOTALL);
        Matcher blocks=tables.matcher(html);
        while(blocks.find()){
            String block=blocks.group(1);ArrayList<String> cells=new ArrayList<>();Matcher cell=Pattern.compile("<td\\b[^>]*>(.*?)</td>",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(block);while(cell.find())cells.add(clean(cell.group(1)));
            Matcher link=Pattern.compile("href=[\"']([^\"']+)[\"']",Pattern.CASE_INSENSITIVE).matcher(block);String midi="",page="";
            while(link.find()){String href=entities(link.group(1));URL absolute=new URL(new URL(BASE+"cgibin/"),href);String host=absolute.getHost();if(!host.equals("www.mutopiaproject.org")&&!host.equals("mutopiaproject.org"))continue;
                if(absolute.getPath().toLowerCase(Locale.ROOT).matches(".*\\.(mid|midi)$"))midi=absolute.toString().replaceFirst("^http:","https:");
                if(absolute.getPath().endsWith("piece-info.cgi"))page=absolute.toString().replaceFirst("^http:","https:");}
            if(cells.size()<10||page.isEmpty()||midi.isEmpty()||!seen.add(page))continue;
            Entry e=new Entry();e.title=cells.get(0);e.composer=cells.get(1).replaceFirst("^by ","");e.instrument=cells.get(4).replaceFirst("^for ","");e.license=cells.get(9);e.page=page;e.midi=midi;results.add(e);
            if(results.size()>=50)break;
        }
        if(results.isEmpty()&&!html.toLowerCase(Locale.ROOT).contains("mutopia"))throw new IOException("返回内容不是曲库页面，请检查网络或稍后重试");
        return results;
    }
    private static String clean(String s){return entities(s.replaceAll("(?s)<[^>]*>"," ")).replaceAll("\\s+"," ").trim();}
    private static String entities(String s){Matcher m=Pattern.compile("&#(x[0-9a-fA-F]+|[0-9]+);").matcher(s);StringBuffer b=new StringBuffer();while(m.find()){String v=m.group(1);String replacement=m.group();try{int cp=Integer.parseInt(v.startsWith("x")?v.substring(1):v,v.startsWith("x")?16:10);if(Character.isValidCodePoint(cp))replacement=new String(Character.toChars(cp));}catch(Exception ignored){}m.appendReplacement(b,Matcher.quoteReplacement(replacement));}m.appendTail(b);return b.toString().replace("&nbsp;"," ").replace("&quot;","\"").replace("&apos;","'").replace("&lt;","<").replace("&gt;",">").replace("&amp;","&");}
}
