package cn.pianolink;

import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class Models {
    public static final int LIMIT=262144, MAX_TIME=1800000;
    public static int integer(JSONObject j,String k,int lo,int hi) throws Exception {
        Object value=j.get(k);
        if(!(value instanceof Number) || ((Number)value).doubleValue()!=((Number)value).intValue()) throw new IOException(k+" 必须为整数");
        int v=((Number)value).intValue();if(v<lo||v>hi) throw new IOException(k+" 超出范围 "+lo+".."+hi);return v;
    }
    public static String read(InputStream in) throws Exception {
        if(in==null) throw new IOException("无法打开文件");
        try(InputStream input=in;ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] b=new byte[4096];int n;while((n=input.read(b))!=-1) {if(out.size()+n>LIMIT) throw new IOException("文件超过 256 KiB");out.write(b,0,n);}
            return new String(out.toByteArray(),StandardCharsets.UTF_8);
        }
    }
    public static JSONObject score(String raw) throws Exception {
        JSONObject j=new JSONObject(raw);integer(j,"version",1,1);
        if(!(j.get("title") instanceof String))throw new IOException("曲名必须是文字");
        String title=j.getString("title").trim();if(title.length()<1||title.length()>64) throw new IOException("曲名需为 1~64 字");
        int bpm=integer(j,"bpm",30,240);JSONArray source=j.getJSONArray("notes");
        if(source.length()<1||source.length()>4096) throw new IOException("曲谱需要 1~4096 个音符");
        ArrayList<JSONObject> notes=new ArrayList<>();
        for(int i=0;i<source.length();i++) {
            JSONObject n=source.getJSONObject(i);
            int at=integer(n,"at",0,MAX_TIME),dur=integer(n,"duration",20,MAX_TIME);
            if((long)at+dur>MAX_TIME) throw new IOException("曲谱总时长最多 30 分钟");
            notes.add(new JSONObject().put("at",at).put("duration",dur).put("note",integer(n,"note",48,95)).put("velocity",integer(n,"velocity",1,127)));
        }
        Collections.sort(notes,(a,b)->Integer.compare(a.optInt("at"),b.optInt("at")));
        JSONArray normalized=new JSONArray();for(JSONObject n:notes) normalized.put(n);
        JSONObject out=new JSONObject().put("version",1).put("title",title).put("bpm",bpm).put("notes",normalized);
        JSONObject sourceMeta=j.optJSONObject("source");
        if(sourceMeta!=null){JSONObject copy=new JSONObject();for(String key:new String[]{"provider","title","composer","license","url","midi","adaptation"}){Object v=sourceMeta.opt(key);if(v instanceof String&&((String)v).length()<=1000)copy.put(key,v);}out.put("source",copy);}
        if(out.toString().getBytes(StandardCharsets.UTF_8).length>LIMIT) throw new IOException("曲谱超过 256 KiB");return out;
    }
    public static JSONObject example() {
        try {
            int[] melody={64,64,65,67,67,65,64,62,60,60,62,64,64,62,62,
                64,64,65,67,67,65,64,62,60,60,62,64,62,60,60};
            int[] beats={2,2,2,2,2,2,2,2,2,2,2,2,3,1,4,
                2,2,2,2,2,2,2,2,2,2,2,2,3,1,4};
            JSONArray a=new JSONArray();int at=0;
            for(int i=0;i<melody.length;i++) {int len=beats[i]*250;a.put(new JSONObject().put("at",at).put("duration",len-50).put("note",melody[i]).put("velocity",80));at+=len;}
            return new JSONObject().put("version",1).put("title","欢乐颂 · 实物演示").put("bpm",120).put("notes",a);
        } catch(JSONException e) {throw new IllegalStateException(e);}
    }
    public static JSONObject event(JSONObject j) throws Exception {
        if(!(j.get("on") instanceof Boolean) || !(j.get("measured") instanceof Boolean)) throw new IOException("事件 on/measured 必须为布尔值");
        return new JSONObject().put("session",j.getString("session")).put("id",integer(j,"id",0,Integer.MAX_VALUE))
            .put("t",integer(j,"t",0,MAX_TIME)).put("key",integer(j,"key",0,47)).put("note",integer(j,"note",48,95))
            .put("velocity",integer(j,"velocity",0,127)).put("on",j.getBoolean("on")).put("measured",j.getBoolean("measured"));
    }
    public static String note(int n) {return new String[]{"C","C♯","D","D♯","E","F","F♯","G","G♯","A","A♯","B"}[n%12]+(n/12-1);}
    public static JSONObject recording(JSONObject j) throws Exception {
        integer(j,"version",1,1);if(!"performance".equals(j.getString("kind"))) throw new IOException("不是演奏记录文件");
        JSONArray a=j.getJSONArray("events");if(a.length()>20000) throw new IOException("事件数量过多");
        int last=-1;Set<Integer> ids=new HashSet<>();String session=j.getString("session");
        for(int i=0;i<a.length();i++) {JSONObject e=event(a.getJSONObject(i));if(!session.equals(e.getString("session"))||e.getInt("t")<last||!ids.add(e.getInt("id"))) throw new IOException("事件顺序或会话无效");last=e.getInt("t");}
        return j;
    }
    /** Convert key events into a score; unmatched down events get a short release. */
    public static JSONObject replayScore(JSONObject recording) throws Exception {
        JSONArray events=recording.getJSONArray("events"),notes=new JSONArray();Map<Integer,JSONObject> down=new HashMap<>();int end=0;
        for(int i=0;i<events.length();i++) {JSONObject e=events.getJSONObject(i);end=e.getInt("t");int key=e.getInt("key");
            if(e.getBoolean("on")) {JSONObject old=down.put(key,e);if(old!=null) addNote(notes,old,end);}
            else {JSONObject start=down.remove(key);if(start!=null) addNote(notes,start,end);}
        }
        for(JSONObject start:down.values()) addNote(notes,start,Math.min(MAX_TIME,end+200));
        if(notes.length()==0) throw new IOException("没有可回放的按下事件");
        return score(new JSONObject().put("version",1).put("title","演奏回放").put("bpm",120).put("notes",notes).toString());
    }
    private static void addNote(JSONArray notes,JSONObject start,int end) throws Exception {
        int at=start.getInt("t"),duration=Math.max(20,end-at);if(at+duration>MAX_TIME) return;
        notes.put(new JSONObject().put("at",at).put("duration",duration).put("note",start.getInt("note")).put("velocity",Math.max(1,start.getInt("velocity"))));
    }
}
