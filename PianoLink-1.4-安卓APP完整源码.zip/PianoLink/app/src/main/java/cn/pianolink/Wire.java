package cn.pianolink;

import java.util.Arrays;

/** Separate from Android so framing and damaged stream recovery can be host-tested. */
public final class Wire {
    public static final int MAX = 768;
    public static final int HELLO=1, BEGIN=16, CHUNK=17, COMMIT=18, GUIDE=32,
            REC_START=48, REC_STOP=49, EVENT=50, ACK=128;
    public interface Receiver { void frame(int type, int seq, byte[] data); }
    public static int crc(byte[] b,int start,int end) {
        int c=0xffff;
        for(int i=start;i<end;i++) { c^=(b[i]&255)<<8; for(int j=0;j<8;j++) c=((c&0x8000)!=0? (c<<1)^0x1021:c<<1)&65535; }
        return c;
    }
    public static byte[] pack(int type,int seq,byte[] data) {
        if(data.length>MAX) throw new IllegalArgumentException("payload too long");
        byte[] b=new byte[data.length+10]; b[0]=0x50;b[1]=0x4c;b[2]=1;b[3]=(byte)type;
        b[4]=(byte)seq;b[5]=(byte)(seq>>8);b[6]=(byte)data.length;b[7]=(byte)(data.length>>8);
        System.arraycopy(data,0,b,8,data.length); int c=crc(b,2,b.length-2);
        b[b.length-2]=(byte)c;b[b.length-1]=(byte)(c>>8);return b;
    }
    public static final class Parser {
        private final byte[] buf=new byte[MAX+10]; private int n; public int badFrames;
        private final Receiver receiver;
        public Parser(Receiver r) { receiver=r; }
        private void drop(int count) { System.arraycopy(buf,count,buf,0,n-count);n-=count; }
        public void feed(byte[] data,int length) {
            for(int k=0;k<length;k++) {
                if(n==buf.length) {drop(1);badFrames++;} buf[n++]=data[k];
                while(n>=2) {
                    if(buf[0]!=0x50 || buf[1]!=0x4c) {drop(1);continue;}
                    if(n<8) break;
                    int len=(buf[6]&255)|((buf[7]&255)<<8);
                    if(buf[2]!=1 || len>MAX) {badFrames++;drop(1);continue;}
                    int total=len+10;if(n<total) break;
                    int c=(buf[total-2]&255)|((buf[total-1]&255)<<8);
                    if(crc(buf,2,total-2)!=c) {badFrames++;drop(1);continue;}
                    int type=buf[3]&255,seq=(buf[4]&255)|((buf[5]&255)<<8);
                    byte[] payload=Arrays.copyOfRange(buf,8,8+len);drop(total);receiver.frame(type,seq,payload);
                }
            }
        }
    }
}
