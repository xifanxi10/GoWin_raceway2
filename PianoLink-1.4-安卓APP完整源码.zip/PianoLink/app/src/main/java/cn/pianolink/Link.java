package cn.pianolink;

import android.bluetooth.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.json.*;

/** A single worker owns requests; the independent reader delivers ACKs and events. */
public final class Link implements AutoCloseable {
    public interface Listener { void event(JSONObject e); void disconnected(String why); }
    private final Listener listener;
    private final Object monitor=new Object();
    private volatile BluetoothSocket socket;
    private volatile boolean open;
    private volatile int generation;
    private boolean demo;
    private int sequence, waiting=-1, waitingType;
    private JSONObject reply;
    public Link(Listener l) {listener=l;}
    public boolean isOpen() {return open;}
    public boolean isDemo() {return demo && open;}
    public void connect(BluetoothDevice device) throws Exception {
        connect(device,false);
    }
    public void connect(BluetoothDevice device,boolean compatible) throws Exception {
        close(); int g=generation;
        UUID spp=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        BluetoothSocket s=compatible?device.createInsecureRfcommSocketToServiceRecord(spp):device.createRfcommSocketToServiceRecord(spp);
        socket=s;
        Thread timeout=new Thread(()-> {try {Thread.sleep(15000);if(g==generation && !open) s.close();} catch(Exception ignored) {} });
        timeout.setDaemon(true);timeout.start();
        try {
            s.connect();if(g!=generation) throw new IOException("连接已取消");
            demo=false;open=true;
            new Thread(()->read(s,g),"HC05-reader").start();
        } catch(IOException e) {
            try{s.close();}catch(IOException ignored){}
            if(g==generation){socket=null;open=false;}
            throw new IOException("HC-05 蓝牙串口连接失败（"+(compatible?"兼容":"标准")+"模式）："+e.getMessage(),e);
        } finally {timeout.interrupt();}
    }
    public void demo() {close();demo=true;open=true;}
    private void read(BluetoothSocket s,int g) {
        Wire.Parser parser=new Wire.Parser((type,seq,data)-> {
            if(g!=generation) return;
            try {
                JSONObject j=new JSONObject(new String(data,StandardCharsets.UTF_8));
                if(type==Wire.ACK) {synchronized(monitor) {if(seq==waiting && j.optInt("for",-1)==waitingType) {reply=j;monitor.notifyAll();}}}
                else if(type==Wire.EVENT) listener.event(j);
            } catch(JSONException ignored) { /* A malformed response never acknowledges a request. */ }
        });
        try {InputStream in=s.getInputStream();byte[] b=new byte[1024];int n;
            while(g==generation && (n=in.read(b))!=-1) parser.feed(b,n);
            throw new EOFException("蓝牙连接已断开");
        } catch(Exception e) {if(g==generation) {close();listener.disconnected(e.getMessage());}}
    }
    /** Call only on the serialized work executor. Retransmissions keep the same sequence. */
    public JSONObject request(int type,JSONObject data) throws Exception {
        if(!open) throw new IOException("请先连接 HC-05 或进入演示模式");
        if(demo) {Thread.sleep(35);return new JSONObject().put("for",type).put("status",0).put("demo",true).put("protocol",1).put("max_blob",262144);}
        final int seq=(++sequence)&65535;
        byte[] frame=Wire.pack(type,seq,data.toString().getBytes(StandardCharsets.UTF_8));
        synchronized(monitor) {waiting=seq;waitingType=type;reply=null;}
        try {
            for(int attempt=0;attempt<3;attempt++) {
                if(!open) throw new IOException("蓝牙已断开");
                OutputStream out=socket.getOutputStream();
                for(int off=0;off<frame.length;off+=16){
                    if(!open)throw new IOException("蓝牙已断开");
                    out.write(frame,off,Math.min(16,frame.length-off));out.flush();
                    if(off+16<frame.length)Thread.sleep(8);
                }
                long until=System.nanoTime()+4000000000L;
                synchronized(monitor) {
                    while(reply==null && open) {long left=until-System.nanoTime();if(left<=0) break;monitor.wait(Math.max(1,left/1000000));}
                    if(reply!=null) {
                        if(reply.optInt("status",-1)!=0) throw new IOException("设备拒绝："+reply.optString("message","status="+reply.optInt("status")));
                        return reply;
                    }
                }
            }
            throw new IOException("设备应答超时（命令="+type+"，序号="+seq+"，已尝试3次）；未收到匹配的单片机确认");
        } finally {synchronized(monitor){waiting=-1;reply=null;}}
    }
    public void close() {
        generation++;open=false;BluetoothSocket s=socket;socket=null;
        if(s!=null) try {s.close();} catch(IOException ignored) {}
        synchronized(monitor){monitor.notifyAll();}
    }
}
