package cn.pianolink;

import android.media.*;
import org.json.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Phone-only sine preview. It is deliberately independent of the FPGA instrument. */
public final class Preview {
    public interface Listener {void position(int millis,long notes,boolean ended);}
    private final AtomicInteger generation=new AtomicInteger();
    public void stop() {generation.incrementAndGet();}
    public void play(JSONObject score,Listener listener) throws Exception {
        stop();int token=generation.get();JSONArray a=score.getJSONArray("notes");int count=a.length();
        int[] starts=new int[count],ends=new int[count],notes=new int[count],vel=new int[count];int length=0;
        for(int i=0;i<count;i++) {JSONObject n=a.getJSONObject(i);starts[i]=n.getInt("at");ends[i]=starts[i]+n.getInt("duration");notes[i]=n.getInt("note");vel[i]=n.getInt("velocity");length=Math.max(length,ends[i]);}
        final int total=length;
        new Thread(()-> {
            AudioTrack track=null;
            try {
                int rate=22050,block=512;int size=Math.max(block*4,AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT));
                track=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()).setBufferSizeInBytes(size).build();
                double[] phases=new double[48],steps=new double[48];for(int k=0;k<48;k++)steps[k]=2*Math.PI*440*Math.pow(2,(k+48-69)/12.0)/rate;
                short[] pcm=new short[block];double[] amplitudes=new double[48];track.play();int activeStart=0,activeEnd=0;
                for(int sample=0;sample<(long)(total+150)*rate/1000 && token==generation.get();sample+=block) {
                    long mask=0;int ms=(int)((long)sample*1000/rate);
                    for(int k=0;k<48;k++)amplitudes[k]=0;
                    while(activeEnd<count && starts[activeEnd]<=ms+24)activeEnd++;
                    while(activeStart<activeEnd && ends[activeStart]<ms-30)activeStart++;
                    for(int j=activeStart;j<activeEnd;j++)if(ms>=starts[j] && ms<ends[j]) {int k=notes[j]-48;double env=Math.min(1,Math.min((ms-starts[j]+1)/12.0,(ends[j]-ms)/25.0));amplitudes[k]=Math.max(amplitudes[k],vel[j]/127.0*env);mask|=1L<<k;}
                    for(int i=0;i<block;i++) {double v=0;for(int k=0;k<48;k++)if(amplitudes[k]>0) {v+=Math.sin(phases[k])*amplitudes[k];phases[k]+=steps[k];if(phases[k]>2*Math.PI)phases[k]-=2*Math.PI;}pcm[i]=(short)(Math.tanh(v*0.2)*19000);}
                    if(track.write(pcm,0,pcm.length)<0)throw new IllegalStateException("音频输出不可用");listener.position(ms,mask,false);
                }
                if(token==generation.get()) listener.position(total,0,true);
            } catch(Exception ignored) {if(token==generation.get())listener.position(-1,0,true);}
            finally {if(track!=null) {try {track.pause();track.flush();}catch(Exception ignored){}track.release();}}
        },"Phone-preview").start();
    }
}
