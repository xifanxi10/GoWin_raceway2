package cn.pianolink;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

/** Bounded Standard MIDI File type 0/1 reader. No Android APIs, no audio transcription. */
public final class MidiScore {
    public static final int MAX_BYTES=2*1024*1024, MAX_NOTES=20000;
    public static final class Note {
        public long start,end; public int pitch,velocity,part;
        Note(long s,long e,int p,int v,int group){start=s;end=e;pitch=p;velocity=v;part=group;}
    }
    public static final class Part {
        public final int id;public final String name;public int count,min=127,max,sum;
        Part(int id,String name){this.id=id;this.name=name;}
        public String label(){return name+" · "+count+"音 · "+Models.note(min)+"—"+Models.note(max);}
    }
    public static final class Song {
        public final ArrayList<Note> notes=new ArrayList<>();
        public final ArrayList<Part> parts=new ArrayList<>();
        public int bpm=120,unclosed,drums; public boolean tempoChanges,controllers;
        public int recommendedPart(){double best=-1;int id=-1;for(Part p:parts){double avg=p.sum/(double)p.count;if(p.count>=4&&avg>best){best=avg;id=p.id;}}return id;}
        public ArrayList<ArrayList<Note>> segments(int part) throws IOException {
            ArrayList<Note> selected=new ArrayList<>();for(Note n:notes)if(part<0||n.part==part)selected.add(n);
            if(selected.isEmpty())throw new IOException("这个声部没有可导入的音符");
            ArrayList<ArrayList<Note>> all=new ArrayList<>();ArrayList<Note> current=new ArrayList<>();
            for(int i=0;i<selected.size();) {
                int end=i+1;while(end<selected.size()&&selected.get(end).start==selected.get(i).start)end++;
                if(end-i>256)throw new IOException("同一时刻超过256个音符，无法适配当前设备");
                if(!current.isEmpty()&&(current.size()+end-i>256 || selected.get(i).end-current.get(0).start>Models.MAX_TIME)){all.add(current);current=new ArrayList<>();}
                for(int k=i;k<end;k++)current.add(selected.get(k));i=end;
            }
            if(!current.isEmpty())all.add(current);return all;
        }
    }
    public static final class Converted {
        public JSONObject score;public int shifted,shortened;public String details;
    }
    public static Song fromScore(JSONObject score) throws Exception {
        Song song=new Song();song.bpm=score.getInt("bpm");JSONArray notes=score.getJSONArray("notes");Part p=new Part(0,"全部音符");
        for(int i=0;i<notes.length();i++){JSONObject n=notes.getJSONObject(i);long at=n.getLong("at");int pitch=n.getInt("note");song.notes.add(new Note(at,at+n.getInt("duration"),pitch,n.getInt("velocity"),0));p.count++;p.min=Math.min(p.min,pitch);p.max=Math.max(p.max,pitch);p.sum+=pitch;}song.parts.add(p);return song;
    }
    public static Converted convert(Song song,int part,int segment,boolean fold,String title,JSONObject source) throws Exception {
        ArrayList<ArrayList<Note>> chunks=song.segments(part);
        if(segment<0||segment>=chunks.size())throw new IOException("请选择有效段落");
        ArrayList<Note> notes=chunks.get(segment);long origin=notes.get(0).start;JSONArray out=new JSONArray();Converted result=new Converted();
        for(Note n:notes){int pitch=n.pitch;if(pitch<48||pitch>95){if(!fold)throw new IOException("包含超出C3—B6的音符，请选择其他声部或开启八度适配");while(pitch<48)pitch+=12;while(pitch>95)pitch-=12;result.shifted++;}
            long at=n.start-origin,dur=n.end-n.start;if(dur<20){dur=20;result.shortened++;}if(at+dur>Models.MAX_TIME)throw new IOException("所选段落超过30分钟");
            out.put(new JSONObject().put("at",at).put("duration",dur).put("note",pitch).put("velocity",n.velocity));}
        String suffix=" · 第"+(segment+1)+"/"+chunks.size()+"段";
        String name=title.trim();if(name.isEmpty())name="MIDI曲目";if(name.length()>64-suffix.length())name=name.substring(0,64-suffix.length());
        result.score=Models.score(new JSONObject().put("version",1).put("title",name+suffix).put("bpm",Math.max(30,Math.min(240,song.bpm))).put("notes",out).toString());
        result.details="选择"+notes.size()+"个音符；"+result.shifted+"个音符按八度移入48键；"+result.shortened+"个短音延至20ms。";
        if(song.tempoChanges)result.details+="保留原曲变速时间。";
        if(song.unclosed>0)result.details+="原文件有"+song.unclosed+"个未闭合音符，已舍弃。";
        if(source!=null){JSONObject meta=new JSONObject(source.toString());meta.put("adaptation",result.details+"选取声部/段落，移除段首空白；踏板、弯音及音色控制不参与键位指引。");result.score.put("source",meta);}
        if(result.score.toString().getBytes(StandardCharsets.UTF_8).length>32768)throw new IOException("转换结果超过单片机32KiB限制");return result;
    }
    private static final class Tempo {long tick;int micros;double time;Tempo(long t,int m){tick=t;micros=m;}}
    private static final class On {long tick;int velocity;On(long t,int v){tick=t;velocity=v;}}
    private static final class Reader {
        final byte[] data;int p,end;
        Reader(byte[] d){data=d;end=d.length;}
        int u8() throws IOException {if(p>=end)throw new IOException("MIDI文件被截断");return data[p++]&255;}
        int u16() throws IOException {return (u8()<<8)|u8();}
        long u32() throws IOException {return ((long)u16()<<16)|u16();}
        long variable() throws IOException {long n=0;for(int i=0;i<4;i++){int b=u8();n=(n<<7)|(b&127);if((b&128)==0)return n;}throw new IOException("无效的MIDI变长整数");}
        int length() throws IOException {long n=variable();if(n>end-p)throw new IOException("MIDI事件长度超出文件");return (int)n;}
        String tag() throws IOException {StringBuilder b=new StringBuilder();for(int i=0;i<4;i++)b.append((char)u8());return b.toString();}
        int dataByte() throws IOException {int b=u8();if(b>127)throw new IOException("无效的MIDI数据字节");return b;}
    }
    public static Song parse(byte[] bytes) throws Exception {
        if(bytes.length>MAX_BYTES)throw new IOException("MIDI文件超过2MiB");Reader r=new Reader(bytes);
        if(!r.tag().equals("MThd"))throw new IOException("不是标准MIDI文件，请下载.mid或.midi，不是MP3或网页");
        long header=r.u32();if(header<6||header>r.end-r.p)throw new IOException("无效的MIDI文件头");int format=r.u16(),tracks=r.u16(),division=r.u16();
        if(format>1||format<0)throw new IOException("目前支持MIDI类型0和1，不支持类型2");
        if(tracks<1||tracks>128||(format==0&&tracks!=1))throw new IOException("无效的MIDI音轨数量");
        if((division&32768)!=0||division==0)throw new IOException("暂不支持SMPTE时间基准的MIDI");r.p+=(int)header-6;
        Song song=new Song();ArrayList<Tempo> tempos=new ArrayList<>();tempos.add(new Tempo(0,500000));Map<Integer,String> names=new HashMap<>();int events=0;
        for(int track=0;track<tracks;track++){
            r.end=bytes.length;if(!r.tag().equals("MTrk"))throw new IOException("找不到MIDI音轨块");long trackLen=r.u32();if(trackLen>r.end-r.p)throw new IOException("音轨被截断");int end=r.p+(int)trackLen;r.end=end;
            long tick=0;int running=0;String name="音轨 "+(track+1);Map<Integer,ArrayDeque<On>> active=new HashMap<>();
            while(r.p<end){if(++events>200000)throw new IOException("MIDI事件过多");tick+=r.variable();if(tick>1000000000L)throw new IOException("MIDI时间范围过大");int status=r.u8();
                if(status<128){if(running==0)throw new IOException("缺少MIDI运行状态");r.p--;status=running;}
                if(status==255){int type=r.u8(),len=r.length();
                    if(type==81){if(len!=3)throw new IOException("无效的速度事件");int micros=((bytes[r.p]&255)<<16)|((bytes[r.p+1]&255)<<8)|(bytes[r.p+2]&255);if(micros==0)throw new IOException("速度不能为0");if(tempos.size()>=10000)throw new IOException("变速事件过多");tempos.add(new Tempo(tick,micros));}
                    if(type==3){name=new String(bytes,r.p,Math.min(len,128),StandardCharsets.UTF_8).replaceAll("[\\p{Cntrl}]", " ").trim();if(name.isEmpty())name="音轨 "+(track+1);}
                    r.p+=len;if(type==47){if(len!=0)throw new IOException("无效的音轨结束事件");r.p=end;break;}continue;
                }
                if(status==240||status==247){int len=r.length();r.p+=len;running=0;continue;}
                if(status<128||status>=240)throw new IOException("不支持的MIDI系统事件");running=status;
                int channel=status&15,kind=status&240,d1=r.dataByte(),d2=(kind==192||kind==208)?0:r.dataByte();
                if(kind==176||kind==224)song.controllers=true;
                if(kind==144&&d2>0){if(channel==9){song.drums++;continue;}int key=channel*128+d1;ArrayDeque<On> q=active.get(key);if(q==null){q=new ArrayDeque<>();active.put(key,q);}if(q.size()>=256)throw new IOException("同音重叠过多");q.addLast(new On(tick,d2));}
                else if(kind==128||(kind==144&&d2==0)){int key=channel*128+d1;ArrayDeque<On> q=active.get(key);if(q!=null&&!q.isEmpty()){On on=q.removeFirst();if(tick>on.tick){if(song.notes.size()>=MAX_NOTES)throw new IOException("MIDI音符超过20000个");song.notes.add(new Note(on.tick,tick,d1,on.velocity,track*16+channel));}}}
            }
            for(ArrayDeque<On> q:active.values())song.unclosed+=q.size();for(int ch=0;ch<16;ch++)names.put(track*16+ch,name+" / 通道"+(ch+1));r.p=end;
        }
        if(song.notes.isEmpty())throw new IOException("MIDI里没有可用的有音高音符（打击乐不导入）");
        Collections.sort(tempos,Comparator.comparingLong(t->t.tick));ArrayList<Tempo> timeline=new ArrayList<>();
        for(Tempo t:tempos){if(!timeline.isEmpty()&&timeline.get(timeline.size()-1).tick==t.tick)timeline.set(timeline.size()-1,t);else timeline.add(t);}
        for(int i=1;i<timeline.size();i++){Tempo before=timeline.get(i-1),t=timeline.get(i);t.time=before.time+(t.tick-before.tick)*(double)before.micros/division;}
        song.bpm=(int)Math.round(60000000.0/timeline.get(0).micros);song.tempoChanges=timeline.size()>1;
        Map<Integer,Part> parts=new TreeMap<>();for(Note n:song.notes){n.start=millis(timeline,n.start,division);n.end=millis(timeline,n.end,division);Part part=parts.get(n.part);if(part==null){part=new Part(n.part,names.get(n.part));parts.put(n.part,part);}part.count++;part.min=Math.min(part.min,n.pitch);part.max=Math.max(part.max,n.pitch);part.sum+=n.pitch;}
        song.parts.addAll(parts.values());Collections.sort(song.notes,Comparator.comparingLong((Note n)->n.start).thenComparingInt(n->n.pitch));return song;
    }
    private static long millis(ArrayList<Tempo> tempo,long tick,int ppqn) {
        int low=0,high=tempo.size();while(low+1<high){int mid=(low+high)/2;if(tempo.get(mid).tick<=tick)low=mid;else high=mid;}
        Tempo t=tempo.get(low);return Math.round((t.time+(tick-t.tick)*(double)t.micros/ppqn)/1000.0);
    }
}
