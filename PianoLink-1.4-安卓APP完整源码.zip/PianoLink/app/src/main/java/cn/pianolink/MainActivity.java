package cn.pianolink;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity implements Link.Listener {
    private final int BG=0xfff5f7f3, INK=0xff18342d, GREEN=0xff176b5b, MUTED=0xff63766c;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Preview preview=new Preview();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private Link link;
    private LinearLayout root,body,nav;
    private TextView connection,status,progress,recordCount,playPosition;
    private KeysView keysView;
    private int page=1;
    private String searchTerm="鸡你太美",searchInfo="免费曲库可直接下载；流行曲可到网站查找 MIDI 后导入。";
    private ArrayList<OnlineCatalog.Entry> searchResults=new ArrayList<>();
    private int searchOffset,deviceMaxNotes=256,deviceMaxBlob=32768;
    private boolean busy,ready,recording,destroyed,recordDemo,recordComplete;
    private JSONObject score,lastRecord;
    private JSONArray events=new JSONArray();
    private final Set<Integer> eventIds=new HashSet<>();
    private String session="",notice="就绪 · 可先进入演示模式体验",recordProblem="";
    private long recordStart;
    private int demoId,lastEventId=-1,lastTime=-1;
    private int[] mapping=new int[48];
    private byte[] exportBytes;
    private String importKind="score";
    private final ArrayList<String> log=new ArrayList<>();
    interface Job {String run() throws Exception;}
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        link=new Link(this);score=Models.example();for(int i=0;i<48;i++)mapping[i]=48+i;
        loadSaved();if("小星星 · 入门练习".equals(score.optString("title")))score=Models.example();render();
    }
    private int dp(float n) {return (int)(getResources().getDisplayMetrics().density*n+0.5f);}
    private TextView text(String s,int size,int color) {TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,dp(4),0,dp(4));return t;}
    private GradientDrawable shape(int color,int radius) {GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private void title(LinearLayout box,String label,String detail) {box.addView(text(label,21,INK));box.addView(text(detail,13,MUTED));}
    private LinearLayout card(String label,String detail) {
        LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(dp(18),dp(14),dp(18),dp(16));c.setBackground(shape(Color.WHITE,18));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(14));body.addView(c,p);title(c,label,detail);return c;
    }
    private Button button(LinearLayout box,String label,Runnable action) {Button b=new Button(this);b.setText(label);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(GREEN);box.addView(b,new LinearLayout.LayoutParams(-1,dp(48)));b.setOnClickListener(v->action.run());return b;}
    private EditText field(LinearLayout box,String hint,String value) {EditText e=new EditText(this);e.setText(value);e.setHint(hint);e.setSingleLine(true);e.setTextSize(14);box.addView(e,new LinearLayout.LayoutParams(-1,dp(52)));return e;}
    private void render() {
        if(destroyed)return;
        root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);
        root.setPadding(dp(18),dp(12),dp(18),dp(8));root.setFitsSystemWindows(true);setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets)-> {v.setPadding(dp(18),dp(12)+insets.getSystemWindowInsetTop(),dp(18),dp(8)+insets.getSystemWindowInsetBottom());return insets;});
        root.addView(text("琴联  /  PianoLink",27,INK));
        connection=text(connectionLabel(),13,GREEN);root.addView(connection);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        body=new LinearLayout(this);body.setOrientation(1);body.setPadding(0,dp(16),0,dp(12));scroll.addView(body);
        keysView=null;recordCount=null;playPosition=null;progress=null;
        if(page==0)connectionPage();else if(page==1)scorePage();else if(page==2)mappingPage();else if(page==3)recordPage();else if(page==5)onlinePage();else helpPage();
        status=text(notice,12,MUTED);status.setMaxLines(3);root.addView(status);
        nav=new LinearLayout(this);String[] names={"连接","找曲","曲谱","键位","演奏","说明"};int[] pages={0,5,1,2,3,4};
        for(int i=0;i<names.length;i++){final int tab=pages[i];TextView t=text(names[i],14,page==tab?GREEN:MUTED);t.setGravity(Gravity.CENTER);t.setPadding(0,dp(12),0,dp(12));if(page==tab)t.setBackground(shape(0xffe0ece5,12));nav.addView(t,new LinearLayout.LayoutParams(0,dp(48),1));t.setOnClickListener(v->{page=tab;render();});}root.addView(nav);
    }
    private String connectionLabel() {return !link.isOpen()?"○ 未连接设备  ·  数据保存在本机":link.isDemo()?"● 演示模式  ·  没有连接真实硬件":ready?"● HC-05 已连接  ·  单片机协议已响应":"● 蓝牙已连接  ·  等待单片机协议";}
    private void say(String msg) {notice=msg;log.add(new SimpleDateFormat("HH:mm:ss",Locale.CHINA).format(new Date())+"  "+msg);if(log.size()>50)log.remove(0);if(status!=null)status.setText(msg);if(connection!=null)connection.setText(connectionLabel());}
    private void fail(Exception e) {String detail="操作未完成："+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage());say(detail);new AlertDialog.Builder(this).setTitle("操作结果").setMessage(detail).setPositiveButton("知道了",null).setNeutralButton("复制错误",(d,w)->{android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null)cm.setPrimaryClip(ClipData.newPlainText("PianoLink",detail));}).show();}
    private void job(Job action) {
        if(busy) {say("正在处理上一项操作，请稍候");return;}
        busy=true;worker.execute(()-> {try {String result=action.run();ui(()->{busy=false;say(result);render();});}catch(Exception e){ui(()->{busy=false;fail(e);render();});}});
    }
    private void ui(Runnable action) {runOnUiThread(()->{if(!destroyed)action.run();});}
    private boolean canSend() {if(!ready||!link.isOpen()) {say("请先连接并完成协议握手，或进入演示模式");return false;}if(recording){say("请先结束演奏记录，再修改设备状态");return false;}return true;}
    private void connectionPage() {
        LinearLayout c=card("让手机与琴连接","HC-05 经典蓝牙串口 · Android 8.0 及以上");
        c.addView(text("首次使用：先在系统蓝牙设置中完成 HC-05 配对，再回到这里选择设备。",14,INK));
        button(c,"打开系统蓝牙设置",()->startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
        button(c,"选择已配对设备",this::chooseDevice);
        button(c,"重新检测单片机协议",()->{if(!link.isOpen()){say("请先连接蓝牙");return;}job(()->{handshake();return "单片机协议握手成功";});});
        button(c,"断开连接",()->{link.close();ready=false;finishInterrupted("用户断开连接");say("已断开连接");render();});
        LinearLayout d=card("暂时没有连接硬件？","先验证手机端，再适配 STM32 与 RGB 屏幕");
        button(d,"进入演示模式",()->{if(busy||recording){say("请先结束当前操作");return;}link.demo();ready=true;say("已进入演示模式，所有设备应答均为模拟");render();});
        d.addView(text("演示模式可体验曲谱传输、键位保存和事件记录。真实 HC-05 连接不代表单片机已经支持协议。",13,MUTED));
    }
    private boolean permission() {
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},7);return false;}return true;
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==7){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)chooseDevice();else say("需要“附近的设备”权限才能连接 HC-05，可在应用设置中授权");}}
    private void chooseDevice() {
        if(busy||recording){say("请先结束当前操作");return;}if(!permission())return;
        try {
            BluetoothManager manager=getSystemService(BluetoothManager.class);BluetoothAdapter adapter=manager==null?null:manager.getAdapter();
            if(adapter==null){say("这台设备没有蓝牙适配器，可使用演示模式");return;}
            if(!adapter.isEnabled()){startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));return;}
            ArrayList<BluetoothDevice> devices=new ArrayList<>(adapter.getBondedDevices());
            Collections.sort(devices,(a,b)->String.valueOf(a.getName()).compareTo(String.valueOf(b.getName())));
            if(devices.isEmpty()){say("没有已配对设备，请先在系统蓝牙设置中配对 HC-05");return;}
            String[] labels=new String[devices.size()];for(int i=0;i<labels.length;i++)labels[i]=devices.get(i).getName()+"\n"+devices.get(i).getAddress();
            new AlertDialog.Builder(this).setTitle("选择 HC-05").setItems(labels,(d,w)->
                new AlertDialog.Builder(this).setTitle("选择连接方式")
                .setItems(new String[]{"标准连接（优先）","兼容连接（标准失败时尝试，安全性较低）"},(dialog,mode)->job(()->{
                    ready=false;link.connect(devices.get(w),mode==1);
                    ui(()->say("HC-05 蓝牙串口已连接，正在等待单片机应答"));
                    try{handshake();}catch(Exception e){throw new IOException("蓝牙已连通，但单片机握手失败："+e.getMessage(),e);}
                    return "HC-05 与单片机协议已连接";
                })).setNegativeButton("取消",null).show()
            ).setNegativeButton("取消",null).show();
        }catch(Exception e){fail(e);}
    }
    private void handshake() throws Exception {ready=false;JSONObject ack=link.request(Wire.HELLO,new JSONObject().put("app","PianoLink").put("protocol",1).put("nonce",UUID.randomUUID().toString()));if(ack.optInt("protocol",-1)!=1)throw new IOException("设备协议版本不兼容");deviceMaxNotes=Math.max(1,Math.min(4096,ack.optInt("max_notes",256)));deviceMaxBlob=Math.max(1,Math.min(Models.LIMIT,ack.optInt("max_blob",32768)));ready=link.isOpen();}
    private void scorePage() {
        LinearLayout find=card("在线找曲","搜索、下载 MIDI，再转换为琴能接收的练习段落");
        button(find,"搜索在线曲目",()->{page=5;render();});
        button(find,"导入已下载的 MIDI",()->pick("midi"));
        LinearLayout c=card(score.optString("title"),score.optInt("bpm")+" BPM  ·  "+score.optJSONArray("notes").length()+" 个音符  ·  C3—B6");
        JSONObject source=score.optJSONObject("source");if(source!=null)c.addView(text("来源："+source.optString("provider")+" · "+source.optString("composer")+"\n"+source.optString("license")+"\n"+source.optString("adaptation"),12,MUTED));
        playPosition=text("手机预听使用合成提示音",13,MUTED);c.addView(playPosition);
        keysView=new KeysView();c.addView(keysView,new LinearLayout.LayoutParams(-1,dp(188)));
        button(c,"手机预听",()->play(score));button(c,"停止预听",this::stopPreview);
        c.addView(text("实物演奏：手机发送当前曲目，由 STM32 控制 FPGA 发声。请先连接设备，并在琴的屏幕上解除静音。",14,INK));
        button(c,"实物演奏 · 上传当前曲目并播放",this::playOnPiano);
        button(c,"停止实物演奏",()->guide("stop"));
        button(c,"将当前曲谱分段适配",()->{try{showMidiConvert(MidiScore.fromScore(score),score.optString("title"),score.optJSONObject("source"));}catch(Exception e){fail(e);}});
        button(c,"传输曲谱到单片机",()->sendObject("score",score));
        button(c,"单片机开始屏幕指引",()->guide("start"));button(c,"单片机停止指引 / 回放",()->guide("stop"));
        progress=text("曲谱传输完成后，可由单片机本地计时指引",12,MUTED);c.addView(progress);
        LinearLayout d=card("我的曲谱","导入 PianoLink JSON，或从 HTTPS 地址下载同格式曲谱");
        button(d,"选择已保存曲谱",this::chooseScore);
        button(d,"从文件导入曲谱",()->pick("score"));
        EditText url=field(d,"https://…/score.json","");url.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);
        button(d,"从网址下载并保存",()->download(url.getText().toString().trim()));
        button(d,"导出当前曲谱",()->export(score,"score.json"));
        button(d,"载入《欢乐颂》演示曲",()->{score=Models.example();try{saveScore();say("已载入《欢乐颂》，可选手机预听或实物演奏");render();}catch(Exception e){fail(e);}});
    }
    private void checkCapacity(String kind,JSONObject object) throws Exception {
        if(kind.equals("score")&&object.getJSONArray("notes").length()>deviceMaxNotes)throw new IOException("这首超过设备的"+deviceMaxNotes+"音符上限，请先点击“将当前曲谱分段适配”");
        if(object.toString().getBytes(StandardCharsets.UTF_8).length>deviceMaxBlob)throw new IOException("曲谱超过设备存储上限，请选择更短段落");
    }
    private void onlinePage() {
        LinearLayout c=card("找到你想弹的曲目","免费公开曲库 + 流行曲网页查找");
        EditText query=field(c,"曲名或作曲家，例如：小星星、致爱丽丝",searchTerm);
        query.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){searchTerm=s.toString();}public void afterTextChanged(android.text.Editable e){}});
        button(c,"搜索免费曲库",()->searchOnline(0));
        button(c,"全网搜索这首曲目的 MIDI",()->{String q=OnlineCatalog.keyword(searchTerm);if(q.trim().isEmpty()){say("先输入曲名");return;}try{openWeb("https://www.bing.com/search?q="+URLEncoder.encode(q+" MIDI 下载","UTF-8"));}catch(Exception e){fail(e);}});
        button(c,"我已下载 MIDI，选择文件导入",()->pick("midi"));
        c.addView(text("免费曲库来源：Mutopia，以古典和传统曲目为主。流行曲可能需要在原网站登录或购买后下载；得到 .mid/.midi 文件后回来导入。",13,MUTED));
        if(OnlineCatalog.keyword(searchTerm).contains("只因你太美")) {
            LinearLayout hit=card("只因你太美（鸡你太美）","已核对的曲目网页 · MidiShow · SWIN-S");
            hit.addView(text("这是网页下载入口，尚未下载到手机。网站可能要求登录或积分；按网站提示下载 MIDI 后，返回这里导入。",13,INK));
            button(hit,"打开《只因你太美》下载网页",()->openWeb("https://www.midishow.com/midi/179325.html"));
            button(hit,"导入下载好的《只因你太美》MIDI",()->pick("midi"));
        }
        LinearLayout examples=card("试试公开曲库","这些搜索词可直接查询免费 MIDI");
        for(String name:new String[]{"致爱丽丝","小星星","巴赫"})button(examples,name,()->{searchTerm=name;searchOnline(0);});
        body.addView(text(searchInfo,13,MUTED));
        for(OnlineCatalog.Entry entry:searchResults){LinearLayout result=card(entry.title,entry.composer+" · "+entry.instrument);result.addView(text(entry.license+" · Mutopia Project",12,MUTED));button(result,"下载 MIDI 并选择练习段落",()->downloadMidi(entry));button(result,"查看曲目原网页",()->openWeb(entry.page));}
        if(searchOffset>0)button(body,"上一页",()->searchOnline(Math.max(0,searchOffset-10)));
        if(searchResults.size()>=10)button(body,"下一页",()->searchOnline(searchOffset+10));
    }
    private void searchOnline(int offset) {
        final String query=searchTerm.trim();if(query.isEmpty()){say("请输入曲名或作曲家");return;}
        if(recording){say("请先结束记录再搜索曲谱");return;}
        say("正在查询公开曲库："+query);
        job(()->{ArrayList<OnlineCatalog.Entry> found=OnlineCatalog.search(query,offset);searchResults=found;searchOffset=offset;searchInfo=found.isEmpty()?"公开曲库没有找到匹配曲目。可用上面的“全网搜索”查找 MIDI，再导入下载文件。":"公开曲库结果 · "+query+" · 第"+(offset/10+1)+"页，共"+found.size()+"项";return searchInfo;});
    }
    private void openWeb(String address) {
        if(recording||busy){say("请先结束当前操作，再打开网页");return;}
        try{URL u=new URL(address);if(!u.getProtocol().equals("https"))throw new IOException("网页地址无效");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(address)));}catch(Exception e){fail(e);}
    }
    private void downloadMidi(OnlineCatalog.Entry entry) {
        if(recording){say("请先结束记录");return;}
        say("正在下载并解析 "+entry.title);
        job(()->{byte[] data=OnlineCatalog.fetch(new URL(entry.midi),MidiScore.MAX_BYTES,true);MidiScore.Song midi=MidiScore.parse(data);JSONObject source=entry.source();ui(()->showMidiConvert(midi,entry.title,source));return "MIDI 已读取，请选择声部和段落";});
    }
    private void showMidiConvert(MidiScore.Song midi,String originalTitle,JSONObject source) {
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(20),dp(10),dp(20),dp(10));
        box.addView(text("读取到 "+midi.notes.size()+" 个音符。选择声部后，每段最多256音符；不会把整首长曲静默截断。",13,INK));
        EditText title=field(box,"保存曲名",originalTitle);
        box.addView(text("选择声部（默认优先较高音区，可先试听）",13,MUTED));
        Spinner part=new Spinner(this);ArrayList<String> labels=new ArrayList<>();labels.add("全部声部（不含打击乐）");int recommended=0;for(int i=0;i<midi.parts.size();i++){MidiScore.Part p=midi.parts.get(i);labels.add(p.label());if(p.id==midi.recommendedPart())recommended=i+1;}
        part.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));box.addView(part);part.setSelection(recommended);
        box.addView(text("选择练习段落",13,MUTED));Spinner section=new Spinner(this);box.addView(section);
        CheckBox fold=new CheckBox(this);fold.setText("将超出48键的音符按八度移入（会改变音区）");fold.setTextSize(13);fold.setChecked(true);box.addView(fold);
        TextView summary=text("",13,GREEN);box.addView(summary);
        box.addView(text("保留音符时值与原曲变速；不导入踏板、弯音、音色和打击乐。手机预听为提示音，设备仍用原有固定力度。",12,MUTED));
        Runnable update=()->{try{int selected=part.getSelectedItemPosition(),id=selected==0?-1:midi.parts.get(selected-1).id;MidiScore.Converted converted=MidiScore.convert(midi,id,section.getSelectedItemPosition(),fold.isChecked(),title.getText().toString(),source);summary.setText(converted.details);}catch(Exception e){summary.setText(e.getMessage());}};
        Runnable refresh=()->{try{int selected=part.getSelectedItemPosition(),id=selected==0?-1:midi.parts.get(selected-1).id;ArrayList<ArrayList<MidiScore.Note>> chunks=midi.segments(id);ArrayList<String> parts=new ArrayList<>();for(int i=0;i<chunks.size();i++){ArrayList<MidiScore.Note> notes=chunks.get(i);long start=notes.get(0).start;parts.add("第 "+(i+1)+" / "+chunks.size()+" 段 · "+notes.size()+"音 · 原曲 "+(start/60000)+":"+String.format(Locale.ROOT,"%02d",start/1000%60));}section.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,parts));update.run();}catch(Exception e){summary.setText(e.getMessage());}};
        part.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> a,View v,int p,long id){refresh.run();}public void onNothingSelected(AdapterView<?> a){}});
        section.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> a,View v,int p,long id){update.run();}public void onNothingSelected(AdapterView<?> a){}});fold.setOnCheckedChangeListener((b,c)->update.run());refresh.run();
        ScrollView scroll=new ScrollView(this);scroll.addView(box);AlertDialog dialog=new AlertDialog.Builder(this).setTitle("MIDI → 练习曲谱").setView(scroll).setPositiveButton("保存这一段",null).setNeutralButton("试听这一段",null).setNegativeButton("取消",null).create();
        dialog.setOnDismissListener(d->preview.stop());dialog.setOnShowListener(d->{
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{try{int p=part.getSelectedItemPosition();MidiScore.Converted converted=MidiScore.convert(midi,p==0?-1:midi.parts.get(p-1).id,section.getSelectedItemPosition(),fold.isChecked(),title.getText().toString(),source);play(converted.score);}catch(Exception e){summary.setText(e.getMessage());}});
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{int p=part.getSelectedItemPosition();MidiScore.Converted converted=MidiScore.convert(midi,p==0?-1:midi.parts.get(p-1).id,section.getSelectedItemPosition(),fold.isChecked(),title.getText().toString(),source);storeScore(converted.score);score=converted.score;page=1;dialog.dismiss();say("已保存这一段。可手机预听，或连接设备后传输");render();}catch(Exception e){summary.setText("保存失败："+e.getMessage());}});
        });dialog.show();
    }
    private void sendObject(String kind,JSONObject object) {
        if(!canSend())return;JSONObject snapshot;
        try{snapshot=new JSONObject(object.toString());checkCapacity(kind,snapshot);}catch(Exception e){fail(e);return;}
        job(()->{Transfer.send(link,kind,snapshot,(n,total)->ui(()->{if(progress!=null)progress.setText("正在传输 "+n+" / "+total+" 字节");}));return link.isDemo()?"演示：已模拟接收并提交 "+kind:"设备已校验并提交 "+kind;});
    }
    private void playOnPiano() {
        if(!canSend())return;
        if(link.isDemo()){say("实物演奏需要连接真实 HC-05；请退出演示模式并连接琴");return;}
        if(busy){say("正在处理上一项操作，请稍候");return;}
        try {
            final JSONObject current=new JSONObject(score.toString());checkCapacity("score",current);
            stopPreview();say("正在上传《"+current.optString("title")+"》，上传成功后自动启动实物演奏");
            job(()->{
                link.request(Wire.GUIDE,new JSONObject().put("action","stop"));
                Transfer.send(link,"score",current,(n,t)->ui(()->{if(progress!=null)progress.setText("实物演奏曲目上传："+n+" / "+t+" 字节");}));
                link.request(Wire.GUIDE,new JSONObject().put("action","start").put("mode","replay"));
                return "单片机已确认启动《"+current.optString("title")+"》实物演奏";
            });
        }catch(Exception e){fail(e);}
    }
    private void guide(String action) {if(!canSend())return;job(()->{link.request(Wire.GUIDE,new JSONObject().put("action",action).put("mode","guide"));return link.isDemo()?"演示：指引命令已模拟应答":"单片机已接受"+(action.equals("stop")?"停止指引 / 实物演奏":"指引")+"命令";});}
    private void play(JSONObject source) {try {preview.play(source,(ms,mask,ended)->ui(()->{if(keysView!=null)keysView.mask=mask;if(keysView!=null)keysView.invalidate();if(playPosition!=null)playPosition.setText(ms<0?"手机音频输出失败":ended?"预听结束":String.format(Locale.CHINA,"手机预听  %02d:%02d",ms/60000,ms/1000%60));}));say("手机预听中，可用媒体音量调节声音");}catch(Exception e){fail(e);}}
    private void stopPreview(){preview.stop();if(keysView!=null){keysView.mask=0;keysView.invalidate();}say("预听已停止");}
    private void download(String address) {
        job(()->{
            URL url=new URL(address);String raw=null;
            for(int redirects=0;redirects<=4;redirects++) {
                if(!url.getProtocol().equals("https")||url.getUserInfo()!=null)throw new IOException("仅支持不含账号密码的 HTTPS 曲谱地址");
                HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(12000);c.setReadTimeout(15000);
                try {int code=c.getResponseCode();if(code>=300&&code<400){String location=c.getHeaderField("Location");if(location==null)throw new IOException("无效的重定向");url=new URL(url,location);continue;}
                    if(code!=200)throw new IOException("下载失败，HTTP "+code);raw=Models.read(c.getInputStream());break;
                }finally{c.disconnect();}
            }
            if(raw==null)throw new IOException("曲谱网址重定向次数过多");JSONObject parsed=Models.score(raw);storeScore(parsed);score=parsed;return "已下载并保存曲谱："+parsed.getString("title");
        });
    }
    private JSONObject mapObject() throws Exception {JSONArray a=new JSONArray();for(int n:mapping)a.put(n);return new JSONObject().put("version",1).put("base",48).put("notes",a);}
    private void mappingPage() {
        LinearLayout c=card("48 键，自定义你的音阶","点击琴键编辑 MIDI 音符；当前兼容范围 C3—B6（48—95）");
        c.addView(text("上方为物理键号，下方为映射后的音符。设置保存在本机，传输后由 STM32 应用。",13,MUTED));
        for(int row=0;row<8;row++){LinearLayout line=new LinearLayout(this);for(int col=0;col<6;col++){final int k=row*6+col;TextView b=text((k+1)+"\n"+Models.note(mapping[k]),12,GREEN);b.setGravity(Gravity.CENTER);b.setBackground(shape(0xffeaf2ed,8));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(58),1);p.setMargins(dp(2),dp(3),dp(2),dp(3));line.addView(b,p);b.setOnClickListener(v->editKey(k));}c.addView(line);}
        button(c,"传输键位表到单片机",()->{try{sendObject("mapping",mapObject());}catch(Exception e){fail(e);}});
        button(c,"恢复标准 C3—B6",()->{for(int i=0;i<48;i++)mapping[i]=48+i;saveMapping();say("已恢复标准键位；尚未传输到设备");render();});
        button(c,"导出键位表",()->{try{export(mapObject(),"mapping.json");}catch(Exception e){fail(e);}});
        button(c,"导入键位表",()->pick("mapping"));
    }
    private void editKey(int k) {
        String[] values=new String[48];for(int i=0;i<48;i++)values[i]=Models.note(48+i)+"  ·  MIDI "+(48+i);
        new AlertDialog.Builder(this).setTitle("物理键 "+(k+1)+" 的音符").setSingleChoiceItems(values,mapping[k]-48,(d,w)->{mapping[k]=w+48;saveMapping();d.dismiss();say("键位已保存到手机，传输后设备才会应用");render();}).setNegativeButton("取消",null).show();
    }
    private void recordPage() {
        LinearLayout c=card(recording?"正在记录演奏":"把演奏保存下来","保存按下 / 松开、相对时间和力度；不录制麦克风声音");
        recordCount=text(recording?events.length()+" 个事件":lastRecord==null?"还没有演奏记录":"最近记录："+lastRecord.optJSONArray("events").length()+" 个事件",14,GREEN);c.addView(recordCount);
        c.addView(text("实测力度由单片机上报。没有力度传感器时使用固定力度，并标记为非实测。",13,MUTED));
        button(c,recording?"结束并保存演奏":"开始记录演奏",()->{if(recording)stopRecord();else startRecord();});
        if(link.isDemo()) {
            c.addView(text("演示：点击下面按钮生成一对按下与松开事件",12,MUTED));
            LinearLayout row=new LinearLayout(this);for(int key:new int[]{12,14,16,19}) {Button b=new Button(this);b.setText(Models.note(mapping[key]));row.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));b.setOnClickListener(v->demoKey(key));}c.addView(row);
        }
        button(c,"选择已保存演奏",this::chooseRecord);
        button(c,"手机回放最近演奏",()->{if(lastRecord==null){say("请先保存或导入演奏记录");return;}try{play(Models.replayScore(lastRecord));}catch(Exception e){fail(e);}});
        button(c,"停止手机回放",this::stopPreview);
        button(c,"将记录转成分段曲谱",()->{if(lastRecord==null){say("还没有记录");return;}try{JSONObject replay=Models.replayScore(lastRecord);showMidiConvert(MidiScore.fromScore(replay),"演奏回放",null);}catch(Exception e){fail(e);}});
        button(c,"传到单片机并回放",()->replayDevice());
        button(c,"导出演奏 JSON",()->{if(lastRecord!=null)export(lastRecord,"performance.json");else say("还没有记录");});
        button(c,"导入演奏 JSON",()->pick("record"));
        if(lastRecord!=null)c.addView(text((lastRecord.optBoolean("complete")?"完整记录":"中断 / 不完整记录")+" · "+lastRecord.optString("problem"),12,MUTED));
        playPosition=text("回放保留音符、时值和力度；手机音色为预听音色",12,MUTED);c.addView(playPosition);
        keysView=new KeysView();c.addView(keysView,new LinearLayout.LayoutParams(-1,dp(188)));
    }
    private void startRecord() {
        if(!canSend()||busy)return;
        preview.stop();session=UUID.randomUUID().toString();events=new JSONArray();eventIds.clear();lastEventId=-1;lastTime=-1;demoId=0;recordProblem="";recordComplete=false;recording=true;recordDemo=link.isDemo();recordStart=SystemClock.elapsedRealtime();
        job(()->{try{link.request(Wire.REC_START,new JSONObject().put("session",session));return recordDemo?"演示记录已开始，请点击演示琴键":"设备事件记录已开始";}catch(Exception e){ui(()->finishInterrupted("开始记录未获得确认"));throw e;}});
    }
    private void stopRecord() {
        if(busy){say("设备正在响应，请稍候再结束记录");return;}
        job(()->{try{JSONObject ack=link.request(Wire.REC_STOP,new JSONObject().put("session",session));ui(()->{try{
            int total=ack.optInt("event_count",recordDemo?events.length():-1);
            recordComplete=total==events.length()&&recordProblem.isEmpty();if(total!=events.length())recordProblem="设备事件总数未确认或有缺失";
            finishRecord();say("演奏已保存"+(recordComplete?"":"，完整性未确认"));render();
        }catch(Exception e){fail(e);}});return "记录已结束";}catch(Exception e){ui(()->finishInterrupted("停止记录未确认"));throw e;}});
    }
    private void demoKey(int key) {
        if(!recording||!recordDemo){say("请先在演示模式开始记录");return;}
        final String current=session;try{JSONObject down=demoEvent(key,true,++demoId);acceptEvent(down);handler.postDelayed(()->{if(recording&&session.equals(current))try{acceptEvent(demoEvent(key,false,++demoId));}catch(Exception e){fail(e);}},250);}catch(Exception e){fail(e);}
    }
    private JSONObject demoEvent(int key,boolean on,int id) throws Exception {return new JSONObject().put("session",session).put("id",id).put("t",SystemClock.elapsedRealtime()-recordStart).put("key",key).put("note",mapping[key]).put("velocity",on?80:0).put("on",on).put("measured",false);}
    @Override public void event(JSONObject e) {ui(()->{try{acceptEvent(e);}catch(Exception ex){recordProblem="收到无效事件";say("设备事件格式无效："+ex.getMessage());}});}
    private void acceptEvent(JSONObject raw) throws Exception {
        if(!recording||!session.equals(raw.optString("session")))return;
        JSONObject e=Models.event(raw);int id=e.getInt("id"),t=e.getInt("t");if(eventIds.contains(id))return;
        if(id<=lastEventId||t<lastTime){recordProblem="设备事件发生乱序";return;}
        if(id!=lastEventId+1 && !(recordDemo&&lastEventId==-1&&id==1))recordProblem="事件序号有缺失";
        if(events.length()>=1200){finishInterrupted("达到单次 1200 事件上限");link.close();ready=false;say("达到记录容量上限，已保存并断开连接");render();return;}
        eventIds.add(id);lastEventId=id;lastTime=t;events.put(e);
        if(recordCount!=null)recordCount.setText(events.length()+" 个事件 · "+(e.getBoolean("measured")?"实测力度":"固定力度"));
        if(keysView!=null){long bit=1L<<(e.getInt("note")-48);keysView.mask=e.getBoolean("on")?keysView.mask|bit:keysView.mask&~bit;keysView.invalidate();}
    }
    private void finishRecord() throws Exception {
        if(!recording)return;
        HashSet<Integer> held=new HashSet<>();for(int i=0;i<events.length();i++){JSONObject e=events.getJSONObject(i);if(e.getBoolean("on"))held.add(e.getInt("key"));else held.remove(e.getInt("key"));}
        if(!held.isEmpty()){recordComplete=false;recordProblem=recordProblem.isEmpty()?"结束时有琴键未松开，回放会补短释音":recordProblem;}
        recording=false;
        lastRecord=new JSONObject().put("version",1).put("kind","performance").put("session",session).put("created",System.currentTimeMillis()).put("demo",recordDemo).put("complete",recordComplete).put("problem",recordProblem).put("events",events);
        write("record-"+System.currentTimeMillis()+".json",lastRecord.toString());write("last-record.json",lastRecord.toString());
        if(keysView!=null){keysView.mask=0;keysView.invalidate();}
    }
    private void finishInterrupted(String why) {if(recording)try{recordProblem=why;recordComplete=false;finishRecord();}catch(Exception e){fail(e);}}
    @Override public void disconnected(String why) {ui(()->{ready=false;finishInterrupted("蓝牙中断");say("蓝牙已断开，当前记录标为不完整："+why);render();});}
    private void replayDevice() {
        if(!canSend())return;if(lastRecord==null){say("没有可回放的记录");return;}
        try{JSONObject replay=Models.replayScore(lastRecord);checkCapacity("score",replay);job(()->{Transfer.send(link,"score",replay,(n,t)->{});link.request(Wire.GUIDE,new JSONObject().put("action","start").put("mode","replay"));return link.isDemo()?"演示：设备回放命令已模拟应答":"设备已接受演奏回放命令";});}catch(Exception e){fail(e);}
    }
    private void helpPage() {
        LinearLayout c=card("为你的 STM32 + FPGA 而做","手机端 v1.1 · HC-05 SPP");
        c.addView(text("1 先在“连接”页进入演示模式。\n2 在“曲谱”页预听或导入曲谱。\n3 在“键位”页编辑并保存映射。\n4 在“演奏”页记录、回放与导出。\n\n真实硬件使用配套的 STM32 PianoLink 固件。HC-05 仅透传数据，曲谱校验、存储、屏幕指引和事件上报由 STM32 实现。\n\n找曲页可搜索 Mutopia 免费曲库并下载 MIDI。流行曲提供全网搜索，部分网站需在浏览器登录下载，再返回 App 导入。支持 MIDI 类型0/1，按声部和最多256音符分段，可按八度适配C3—B6；不读取 MP3、PDF 或图片。\n\n记录与连接在当前页面会话内工作。请保持应用前台；锁屏、离开应用或退出时会中止会话，并将未结束记录标为不完整。",14,INK));
        LinearLayout d=card("联调日志","最近 50 条状态；不包含配对密码");for(String s:log)d.addView(text(s,12,MUTED));
    }
    private void pick(String kind){if(recording||busy){say("请先结束当前操作");return;}importKind=kind;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,101);}
    private void export(JSONObject object,String name){if(recording||busy){say("请先结束当前操作，再导出文件");return;}try{exportBytes=object.toString().getBytes(StandardCharsets.UTF_8);Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,102);}catch(Exception e){fail(e);}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();if(request==101)job(()->{
        if(importKind.equals("midi")) {
            byte[] dataBytes=OnlineCatalog.read(getContentResolver().openInputStream(uri),MidiScore.MAX_BYTES);
            MidiScore.Song song=MidiScore.parse(dataBytes);String title="导入的MIDI";
            try(android.database.Cursor cursor=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){if(cursor!=null&&cursor.moveToFirst())title=cursor.getString(0).replaceFirst("(?i)\\.midi?$", "");}
            final String name=title;ui(()->showMidiConvert(song,name,null));return "MIDI 已读取，请选择声部和段落";
        }
        String raw=Models.read(getContentResolver().openInputStream(uri));
        if(importKind.equals("score")){JSONObject parsed=Models.score(raw);storeScore(parsed);score=parsed;}
        else if(importKind.equals("mapping")){JSONObject j=new JSONObject(raw);Models.integer(j,"version",1,1);Models.integer(j,"base",48,48);JSONArray a=j.getJSONArray("notes");if(a.length()!=48)throw new IOException("键位表必须包含 48 项");int[] temp=new int[48];for(int n=0;n<48;n++)temp[n]=Models.integer(new JSONObject().put("n",a.get(n)),"n",48,95);mapping=temp;saveMapping();}
        else {lastRecord=Models.recording(new JSONObject(raw));write("last-record.json",lastRecord.toString());write("record-"+System.currentTimeMillis()+".json",lastRecord.toString());}return "文件已导入并保存到手机";
    });else if(request==102 && exportBytes!=null){final byte[] content=exportBytes;job(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException("无法写入目标文件");out.write(content);}return "文件已导出";});}}
    private void write(String file,String value) throws Exception {File target=new File(getFilesDir(),file),temp=new File(getFilesDir(),file+".tmp");try(FileOutputStream out=new FileOutputStream(temp)){out.write(value.getBytes(StandardCharsets.UTF_8));out.getFD().sync();}if(!temp.renameTo(target))throw new IOException("无法保存文件");}
    private String read(String name) throws Exception{return Models.read(openFileInput(name));}
    private void storeScore(JSONObject s) throws Exception{String key="score-"+hex(java.security.MessageDigest.getInstance("SHA-256").digest(s.toString().getBytes(StandardCharsets.UTF_8))).substring(0,16)+".json";write(key,s.toString());write("current-score.json",s.toString());}
    private String hex(byte[] bytes){StringBuilder b=new StringBuilder();for(byte v:bytes)b.append(String.format(Locale.ROOT,"%02x",v&255));return b.toString();}
    private void saveScore() throws Exception{storeScore(score);}
    private void saveMapping(){try{write("mapping.json",mapObject().toString());}catch(Exception e){ui(()->fail(e));}}
    private void loadSaved(){try{score=Models.score(read("current-score.json"));}catch(Exception ignored){}try{JSONArray a=new JSONObject(read("mapping.json")).getJSONArray("notes");if(a.length()==48)for(int i=0;i<48;i++)mapping[i]=a.getInt(i);}catch(Exception ignored){}try{lastRecord=Models.recording(new JSONObject(read("last-record.json")));}catch(Exception ignored){}}
    private void chooseScore(){chooseFile("score-",false);}
    private void chooseRecord(){if(recording){say("请先结束当前记录");return;}chooseFile("record-",true);}
    private void chooseFile(String prefix,boolean rec){ArrayList<File> files=new ArrayList<>();File[] list=getFilesDir().listFiles();if(list!=null)for(File f:list)if(f.getName().startsWith(prefix)&&f.getName().endsWith(".json"))files.add(f);Collections.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));if(files.isEmpty()){say("还没有保存的"+(rec?"演奏":"曲谱"));return;}String[] labels=new String[files.size()];for(int i=0;i<labels.length;i++)try{JSONObject j=new JSONObject(read(files.get(i).getName()));labels[i]=rec?new SimpleDateFormat("MM-dd HH:mm:ss",Locale.CHINA).format(new Date(j.optLong("created",files.get(i).lastModified())))+" · "+j.getJSONArray("events").length()+" 事件"+(j.optBoolean("demo")?" · 演示":""):j.getString("title");}catch(Exception e){labels[i]="无法读取的文件";}new AlertDialog.Builder(this).setTitle(rec?"已保存演奏":"已保存曲谱").setItems(labels,(d,n)->{try{String raw=read(files.get(n).getName());if(rec){lastRecord=Models.recording(new JSONObject(raw));write("last-record.json",lastRecord.toString());}else{score=Models.score(raw);write("current-score.json",score.toString());}say("已载入");render();}catch(Exception e){fail(e);}}).setNegativeButton("取消",null).show();}
    @Override protected void onStop(){super.onStop();preview.stop();if(recording){finishInterrupted("应用离开前台");say("应用离开前台，记录已保存为不完整");}link.close();ready=false;}
    @Override protected void onRestart(){super.onRestart();render();}
    @Override protected void onDestroy(){destroyed=true;preview.stop();link.close();worker.shutdownNow();handler.removeCallbacksAndMessages(null);super.onDestroy();}
    private final class KeysView extends View {
        long mask;Paint p=new Paint(3);KeysView(){super(MainActivity.this);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float w=getWidth()/12f,h=getHeight()/4f;p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));for(int k=0;k<48;k++){float x=(k%12)*w,y=(3-k/12)*h;boolean active=(mask&(1L<<k))!=0;p.setColor(active?GREEN:0xffeef3ed);canvas.drawRoundRect(x+2,y+3,x+w-2,y+h-3,dp(5),dp(5),p);p.setColor(active?Color.WHITE:MUTED);p.setTextSize(dp(9));p.setTextAlign(Paint.Align.CENTER);canvas.drawText(Models.note(k+48),x+w/2,y+h/2+dp(3),p);}}
    }
}
