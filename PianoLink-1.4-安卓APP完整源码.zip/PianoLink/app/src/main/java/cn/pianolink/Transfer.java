package cn.pianolink;

import org.json.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import android.util.Base64;

public final class Transfer {
    private static void request(Link link,int type,JSONObject data,String stage) throws Exception {
        try {link.request(type,data);}catch(Exception e){
            String detail="";
            if(link.isOpen()&&e.getMessage()!=null&&e.getMessage().contains("应答超时")){
                try {JSONObject d=link.request(2,new JSONObject());detail="；接收诊断：固件="+d.optString("fw","未知")+"，串口丢字节="+d.optLong("rxerr")+"，CRC错误="+d.optLong("crc")+"，帧超时="+d.optLong("gaps")+"，已收="+d.optLong("received")+"字节";}
                catch(Exception diagnostic){detail="；诊断未取得："+diagnostic.getMessage();}
            }
            throw new java.io.IOException(stage+"失败："+e.getMessage()+detail,e);
        }
    }
    public interface Progress {void update(int done,int total);}
    public static String send(Link link,String kind,JSONObject object,Progress progress) throws Exception {
        byte[] bytes=object.toString().getBytes(StandardCharsets.UTF_8);
        if(bytes.length>Models.LIMIT) throw new IllegalArgumentException("传输文件超过 256 KiB");
        String id=UUID.randomUUID().toString();StringBuilder sha=new StringBuilder();
        for(byte b:MessageDigest.getInstance("SHA-256").digest(bytes)) sha.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
        request(link,Wire.BEGIN,new JSONObject().put("id",id).put("kind",kind).put("size",bytes.length).put("sha256",sha.toString()),"上传准备 BEGIN");
        for(int off=0;off<bytes.length;off+=96) {
            int count=Math.min(96,bytes.length-off);
            request(link,Wire.CHUNK,new JSONObject().put("id",id).put("offset",off).put("data",Base64.encodeToString(bytes,off,count,Base64.NO_WRAP)),"曲目分块 CHUNK（"+off+" / "+bytes.length+" 字节）");
            progress.update(off+count,bytes.length);
        }
        request(link,Wire.COMMIT,new JSONObject().put("id",id),"曲目提交 COMMIT");return id;
    }
}
